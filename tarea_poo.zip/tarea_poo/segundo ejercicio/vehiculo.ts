export abstract class Vehiculo {
    constructor(public marca: string, public modelo: string, public año: number) {}

    
    abstract calcularImpuesto(): number;

    
    mostrarInformacion(): void {
        console.log(`Marca: ${this.marca}, Modelo: ${this.modelo}, Año: ${this.año}, Impuesto: ${this.calcularImpuesto()}`);
    }
}


export class Coche extends Vehiculo {
    constructor(marca: string, modelo: string, año: number, private precio: number) {
        super(marca, modelo, año);
    }

   
    calcularImpuesto(): number {
        return this.precio * 0.10; 
    }
}


export class Moto extends Vehiculo {
    constructor(marca: string, modelo: string, año: number, private cilindrada: number) {
        super(marca, modelo, año);
    }

  
    calcularImpuesto(): number {
        return this.cilindrada * 0.05; 
    }
}