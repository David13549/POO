
export function validarEntrada(mensaje: string): number {
    let valor: number;
    while (true) {
        const entrada = prompt(mensaje);
        valor = parseFloat(entrada || '');
        if (!isNaN(valor) && valor >= 0) {
            break;
        }
        console.log("Entrada inválida. Por favor, ingrese un número válido.");
    }
    return valor;
}