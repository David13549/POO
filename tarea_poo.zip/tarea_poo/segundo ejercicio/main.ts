import { Vehiculo, Coche, Moto } from './vehiculo';
import { validarEntrada } from './validacion';

function ingresarVehiculo(): void {
    try {
    
        const tipoVehiculo = prompt("Ingrese el tipo de vehículo (1: Coche, 2: Moto): ");

        
        if (tipoVehiculo !== "1" && tipoVehiculo !== "2") {
            throw new Error("Tipo de vehículo no válido.");
        }

   
        const marca = prompt("Ingrese la marca del vehículo: ");
        const modelo = prompt("Ingrese el modelo del vehículo: ");

        if (!marca || !modelo) {
            throw new Error("La marca y el modelo no pueden estar vacíos.");
        }

    
        const año = validarEntrada("Ingrese el año del vehículo: ");

        let vehiculo: Vehiculo;

        if (tipoVehiculo === "1") {
            // Solicitar precio para coche
            const precio = validarEntrada("Ingrese el precio del coche: ");
            vehiculo = new Coche(marca, modelo, año, precio);
        } else {
            
            const cilindrada = validarEntrada("Ingrese la cilindrada de la moto: ");
            vehiculo = new Moto(marca, modelo, año, cilindrada);
        }

        
        vehiculo.mostrarInformacion();
    } catch (error) {
        console.error();
    }
}

ingresarVehiculo();