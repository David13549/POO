export function validarCamposObligatorios(campos: { [key: string]: any }): void {
    for (const [key, value] of Object.entries(campos)) {
        if (!value) {
            throw new Error(`El campo ${key} es obligatorio.`);
        }
    }
}


export function validarIdExistente(id: number, lista: any[], nombreEntidad: string): void {
    const existe = lista.some(item => item.id === id);
    if (!existe) {
        throw new Error(`${nombreEntidad} con id ${id} no encontrado.`);
    }
}
