import { medicos } from "./medico";
import { pacientes } from "./paciente";

export class Cita {
    constructor(
        public id: number,
        public medicoId: number,
        public pacienteId: number,
        public fecha: string,
        public hora: string
    ) {}
}

export let citas: Cita[] = [];

export function agregarCita(id: number, medicoId: number, pacienteId: number, fecha: string, hora: string): void {
    try {
        if (!medicoId && !pacienteId && !fecha && !hora) {
            throw new Error("Todos los campos son obligatorios.");
        }
        const medico = medicos.find(m => m.id === medicoId);
        const paciente = pacientes.find(p => p.id === pacienteId);
        if (!medico && !paciente) {
            throw new Error("Médico o paciente no encontrado.");
        }
        const cita = new Cita(id, medicoId, pacienteId, fecha, hora);
        citas.push(cita);
        console.log("Cita agregada con éxito.");
    } catch (error) {
        console.error("Error al agregar cita:");
    }
}

export function editarCita(id: number, medicoId: number, pacienteId: number, fecha: string, hora: string): void {
    try {
        const cita = citas.find(c => c.id === id);
        if (!cita) {
            throw new Error("Cita no encontrada.");
        }
        cita.medicoId = medicoId;
        cita.pacienteId = pacienteId;
        cita.fecha = fecha;
        cita.hora = hora;
        console.log("Cita editada con éxito.");
    } catch (error) {
        console.error("Error al editar cita:");
    }
}

export function eliminarCita(id: number): void {
    try {
        const index = citas.findIndex(c => c.id === id);
        if (index === -1) {
            throw new Error("Cita no encontrada.");
        }
        citas.splice(index, 1);
        console.log("Cita eliminada con éxito.");
    } catch (error) {
        console.error("Error al eliminar cita:");
    }
}

export function listarCitas(): void {
    if (citas.length === 0) {
        console.log("No hay citas registradas.");
    } else {
        console.log("Listado de citas:");
        citas.forEach(c => {
            const medico = medicos.find(m => m.id === c.medicoId);
            const paciente = pacientes.find(p => p.id === c.pacienteId);
            console.log(`ID: ${c.id}, Médico: ${medico?.nombre}, Paciente: ${paciente?.nombre}, Fecha: ${c.fecha}, Hora: ${c.hora}`);
        });
    }
}

export function listarPacientesPorMedico(medicoId: number): void {
    const citasMedico = citas.filter(c => c.medicoId === medicoId);
    if (citasMedico.length === 0) {
        console.log("No hay pacientes para este médico.");
    } else {
        console.log("Pacientes del médico con ID", medicoId + ":");
        citasMedico.forEach(c => {
            const paciente = pacientes.find(p => p.id === c.pacienteId);
            console.log(`ID: ${paciente?.id}, Nombre: ${paciente?.nombre}`);
        });
    }
}