export class Paciente {
    constructor(
        public id: number,
        public nombre: string,
        public telefono: string
    ) {}
}

export let pacientes: Paciente[] = [];

export function agregarPaciente(id: number, nombre: string, telefono: string): void {
    try {
        if (!nombre && !telefono) {
            throw new Error("Nombre y teléfono son campos obligatorios.");
        }
        const paciente = new Paciente(id, nombre, telefono);
        pacientes.push(paciente);
        console.log("Paciente agregado con éxito.");
    } catch (error) {
        console.error("Error al agregar paciente:" );
    }
}

export function editarPaciente(id: number, nombre: string, telefono: string): void {
    try {
        const paciente = pacientes.find(p => p.id === id);
        if (!paciente) {
            throw new Error("Paciente no encontrado.");
        }
        paciente.nombre = nombre;
        paciente.telefono = telefono;
        console.log("Paciente editado con éxito.");
    } catch (error) {
        console.error("Error al editar paciente:");
    }
}

export function eliminarPaciente(id: number): void {
    try {
        const index = pacientes.findIndex(p => p.id === id);
        if (index === -1) {
            throw new Error("Paciente no encontrado.");
        }
        pacientes.splice(index, 1);
        console.log("Paciente eliminado con éxito.");
    } catch (error) {
        console.error("Error al eliminar paciente:");
    }
}