export class Medico {
    constructor(
        public id: number,
        public nombre: string,
        public especialidad: string
    ) {}
}

export let medicos: Medico[] = [];

export function agregarMedico(id: number, nombre: string, especialidad: string): void {
    try {
        if (!nombre && !especialidad) {
            throw new Error("Nombre y especialidad son campos obligatorios.");
        }
        const medico = new Medico(id, nombre, especialidad);
        medicos.push(medico);
        console.log("Médico agregado con éxito.");
    } catch (error) {
        console.error("Error al agregar médico:");
    }
}

export function editarMedico(id: number, nombre: string, especialidad: string): void {
    try {
        const medico = medicos.find(m => m.id === id);
        if (!medico) {
            throw new Error("Médico no encontrado.");
        }
        medico.nombre = nombre;
        medico.especialidad = especialidad;
        console.log("Médico editado con éxito.");
    } catch (error) {
        console.error("Error al editar médico:");
    }
}

export function eliminarMedico(id: number): void {
    try {
        const index = medicos.findIndex(m => m.id === id);
        if (index === -1) {
            throw new Error("Médico no encontrado.");
        }
        medicos.splice(index, 1);
        console.log("Médico eliminado con éxito.");
    } catch (error) {
        console.error("Error al eliminar médico:");
    }
}

export function listarMedicosPorEspecialidad(especialidad: string): void {
    const medicosEspecialidad = medicos.filter(m => m.especialidad === especialidad);
    if (medicosEspecialidad.length === 0) {
        console.log("No hay médicos con esa especialidad.");
    } else {
        console.log("Médicos de la especialidad", especialidad + ":");
        medicosEspecialidad.forEach(m => console.log(`ID: ${m.id}, Nombre: ${m.nombre}`));
    }
}