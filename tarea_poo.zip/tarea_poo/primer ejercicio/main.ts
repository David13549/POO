import { agregarMedico, listarMedicosPorEspecialidad } from "./medico";
import { agregarPaciente } from "./paciente";
import { agregarCita, listarCitas, listarPacientesPorMedico } from "./citas";